import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommanServiceService {
  Finalselected:any = [];
  constructor() {
    this.Finalselected;
   }
}
