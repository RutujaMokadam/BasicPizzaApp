import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-admin',
  templateUrl: './pizza-admin.component.html',
  styleUrls: ['./pizza-admin.component.css']
})
export class PizzaAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
