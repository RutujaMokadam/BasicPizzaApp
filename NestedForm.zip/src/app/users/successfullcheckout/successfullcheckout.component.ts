import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successfullcheckout',
  templateUrl: './successfullcheckout.component.html',
  styleUrls: ['./successfullcheckout.component.css']
})
export class SuccessfullcheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
