export const productlist = [
    {
        imgurl:"../../images/pizza1.jpg",
        productname:"Mexican Veg Pizza",
        productprice:250,
        quantity:0,
    },
    {
        imgurl:"../../images/pizza2.jpg",
        productname:"Sicilian Pizza",
        productprice:250,
        quantity:0,
    },
    {
        imgurl:"../../images/pizza3.jpg",
        productname:"Paneer Mashroom Pizza",
        productprice:250,
        quantity:0,
    },
    {
        imgurl:"../../images/pizza4.jpg",
        productname:"Indi Chicken Tikka pizza",
        productprice:350,
        quantity:0,
    },
    {
        imgurl:"../../images/pizza5.jpg",
        productname:"chicken sausage pizza ",
        productprice:350,
        quantity:0,
    },
    {
        imgurl:"../../images/pizza6.jpg",
        productname:"Chicken Golden Delight pizza ",
        productprice:350,
        quantity:0,
    },
    {
        imgurl:"../../images/brownie.jpg",
        productname:"Choco Lava cake",
        productprice:150,
        quantity:0,
    },
    {
        imgurl:"../../images/beverage.jpg",
        productname:"Peppsi ",
        productprice:100,
        quantity:0,
    }
]